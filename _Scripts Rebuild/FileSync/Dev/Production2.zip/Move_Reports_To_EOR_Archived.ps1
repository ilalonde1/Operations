﻿param (
    [switch]$WhatIf
)

# ==============================
# CONFIGURATION
# ==============================
$TenantID    = "d9be1f7f-aacf-461a-8d1b-5528b86d540f"
$ClientID    = "5b20a407-0b59-4c75-b2e5-d2cf970c5dbd"
$ClientSecret= "lHV8Q~AcPYpV69rFAThwK9uuqYqcARD_aJmSIbpw"
$SiteID      = "e197528f-6707-4dd5-afec-04964a94c294"
$DriveID     = "b!j1KX4Qdn1U2v7ASWSpTClCkgewh88axOppiZwdiZiLrmnMMBC2KqRKuvmOcSYyYA"
$LogFile     = "C:\Ian\FileSync\Production\Logs\Move_Reports_Log.txt"
$AuditLog    = "C:\Ian\FileSync\Production\Logs\Move_Reports_Audit.csv"

function Log-Message {
    param ([string]$Message)
    $Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    "$Timestamp - $Message" | Out-File -Append -FilePath $LogFile
    Write-Host "$Timestamp - $Message"
}

function Get-AccessToken {
    if ($global:AccessToken -and ($global:TokenExpiration -gt (Get-Date))) {
        return $global:AccessToken
    }
    $Body = @{
        client_id     = $ClientID
        scope         = "https://graph.microsoft.com/.default"
        client_secret = $ClientSecret
        grant_type    = "client_credentials"
    }
    $TokenResponse = Invoke-RestMethod -Uri "https://login.microsoftonline.com/$TenantID/oauth2/v2.0/token" -Method Post -ContentType "application/x-www-form-urlencoded" -Body $Body
    $global:AccessToken = $TokenResponse.access_token
    $global:TokenExpiration = (Get-Date).AddSeconds($TokenResponse.expires_in - 60)
    return $global:AccessToken
}

function Move-ReportFilesToEORFolders {
    Log-Message "========== Starting month-end report move =========="
    if ($WhatIf) { Log-Message "Running in WHATIF mode — no files will be moved." }

    $Headers = @{ "Authorization" = "Bearer $(Get-AccessToken)" }
    $Moves = @()

    $monthYearFolderName = (Get-Date).ToString("MMMM yyyy")

    # Load EOR.csv
    $csvUri = "https://graph.microsoft.com/v1.0/sites/$SiteID/drives/$DriveID/root:/_FIELD REVIEWS TO INITIAL/EOR.csv:/content"
    try {
        $csvContent = Invoke-RestMethod -Uri $csvUri -Headers $Headers -Method Get
        $csvData = $csvContent | ConvertFrom-Csv
        $EORMap = @{}
        foreach ($row in $csvData) {
            $projectNumber = $row.ProjectNumber.Trim().Trim('"')
            $eorLastName   = $row.EOR.Trim().Trim('"')
            $EORMap[$projectNumber] = $eorLastName
            Log-Message "Loaded mapping: $projectNumber => $eorLastName"
        }
    } catch {
        Log-Message "ERROR: Failed to read EOR.csv - $($_.Exception.Message)"
        return
    }

    # Get existing folders under _FIELD REVIEWS TO INITIAL
    $eorFoldersUri = "https://graph.microsoft.com/v1.0/sites/$SiteID/drives/$DriveID/root:/_FIELD REVIEWS TO INITIAL:/children"
    try {
        $eorFoldersResponse = Invoke-RestMethod -Uri $eorFoldersUri -Headers $Headers -Method Get
        $existingEorFolders = $eorFoldersResponse.value | Where-Object { $_.folder } | ForEach-Object { $_.name }

        $EORFolderMap = @{}
        foreach ($folder in $existingEorFolders) {
            foreach ($word in ($folder -split ' ')) {
                $key = $word.ToLower()
                if (-not $EORFolderMap.ContainsKey($key)) {
                    $EORFolderMap[$key] = @()
                }
                $EORFolderMap[$key] += $folder
            }
        }
    } catch {
        Log-Message "ERROR: Could not retrieve EOR folders - $($_.Exception.Message)"
        return
    }

    # Get top-level project folders
    # Get project folders inside _Archived
        $ProjectsUri = "https://graph.microsoft.com/v1.0/sites/$SiteID/drives/$DriveID/root:/_Archived:/children"
    try {
        $Projects = Invoke-RestMethod -Uri $ProjectsUri -Headers $Headers -Method Get
    } catch {
        Log-Message "ERROR: Could not retrieve project folders - $($_.Exception.Message)"
        return
    }

    foreach ($project in $Projects.value) {
        if (-not ($project.folder) -or $project.name -eq "_Archived") { continue }
        if ($project.name -notmatch '^[0-9]{5}-[0-9]{2}') { continue }

        $projectNumber = $project.name.Split(' ')[0]
        $eorName = "CatchAll"

        if ($EORMap.ContainsKey($projectNumber)) {
            $eorLastName = $EORMap[$projectNumber].ToLower()
            if ($EORFolderMap.ContainsKey($eorLastName)) {
                $eorName = $EORFolderMap[$eorLastName][0]
                Log-Message "Matched '$eorLastName' to folder '$eorName'"
            } else {
                Log-Message "No folder match for '$eorLastName'. Using CatchAll."
            }
        } else {
            Log-Message "No EOR mapping for project '$projectNumber'. Using CatchAll."
        }

        $reportFolderPath = "_Archived/$($project.name)/Reports"
        $reportFolderUri = "https://graph.microsoft.com/v1.0/sites/$SiteID/drives/$DriveID/root:/$( [uri]::EscapeDataString($reportFolderPath) ):/children"
        try {
            $reportFiles = Invoke-RestMethod -Uri $reportFolderUri -Headers $Headers -Method Get
        } catch {
            Log-Message "No Reports folder found or accessible for '_Archived/$($project.name)'"
            continue
        }

        if ($reportFiles.value.Count -eq 0) {
            Log-Message "No files in Reports folder for '$($project.name)'"
            continue
        }

        $baseFolderPath = "_FIELD REVIEWS TO INITIAL/$eorName"
        $destFolderPath = "$baseFolderPath/$monthYearFolderName"

        if ($WhatIf) {
            Log-Message "[WhatIf] Would ensure subfolder '$destFolderPath' exists"
        } else {
            $subfolderCheckUri = "https://graph.microsoft.com/v1.0/sites/$SiteID/drives/$DriveID/root:/$( [uri]::EscapeDataString($destFolderPath) )"
            try {
                $existing = Invoke-RestMethod -Uri "$subfolderCheckUri" -Headers $Headers -Method Get -ErrorAction Stop
                Log-Message "Subfolder '$destFolderPath' already exists with ID $($existing.id)"
            } catch {
                Log-Message "Subfolder '$destFolderPath' does not exist. Creating..."
                $createUri = "https://graph.microsoft.com/v1.0/sites/$SiteID/drives/$DriveID/root:/$( [uri]::EscapeDataString($baseFolderPath) ):/children"
                $folderBody = @{ name = $monthYearFolderName; folder = @{} } | ConvertTo-Json
                try {
                    $response = Invoke-RestMethod -Uri $createUri -Headers $Headers -Method Post -Body $folderBody -ContentType "application/json"
                    Log-Message "Created subfolder '$destFolderPath' with ID $($response.id)"
                } catch {
                    Log-Message "ERROR: Could not create subfolder '$destFolderPath' - $($_.Exception.Message)"
                    continue
                }
            }
        }

        foreach ($file in $reportFiles.value) {
            if ($file.folder) { continue }

            $downloadUri = "https://graph.microsoft.com/v1.0/sites/$SiteID/drives/$DriveID/items/$($file.id)/content"
            $tempFile = "$env:TEMP\\$($file.name)"

            try {
                Invoke-RestMethod -Uri $downloadUri -Headers $Headers -OutFile $tempFile
                Log-Message "Downloaded '$($file.name)' to temp file"
            } catch {
                Log-Message "ERROR downloading '$($file.name)': $($_.Exception.Message)"
                continue
            }

            $uploadUri = "https://graph.microsoft.com/v1.0/sites/$SiteID/drives/$DriveID/root:/$( [uri]::EscapeDataString("$destFolderPath/$($file.name)") ):/content"
            try {
                Invoke-RestMethod -Uri $uploadUri -Headers $Headers -Method PUT -InFile $tempFile -ContentType "application/octet-stream"
                Log-Message "Uploaded '$($file.name)' to '$destFolderPath'"
            } catch {
                Log-Message "ERROR uploading '$($file.name)': $($_.Exception.Message)"
                continue
            }

            $deleteUri = "https://graph.microsoft.com/v1.0/sites/$SiteID/drives/$DriveID/items/$($file.id)"
            try {
                Invoke-RestMethod -Uri $deleteUri -Headers $Headers -Method DELETE
                Log-Message "Deleted original file '$($file.name)' after copy"
            } catch {
                Log-Message "ERROR deleting original file '$($file.name)': $($_.Exception.Message)"
            }

            $Moves += [PSCustomObject]@{
                Project      = $project.name
                FileName     = $file.name
                Destination  = $destFolderPath
                Time         = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
                Simulated    = $WhatIf.IsPresent
            }
        }
    }

    if ($Moves.Count -gt 0) {
        $Moves | Export-Csv -Path $AuditLog -NoTypeInformation -Encoding UTF8
        Log-Message "Audit log written to $AuditLog"
        Log-Message "Total files moved: $($Moves.Count)"
        foreach ($entry in $Moves) {
            Log-Message " - $($entry.FileName) => $($entry.Destination)"
        }
    } else {
        Log-Message "No files were moved."
    }

    Log-Message "========== Month-end report move complete =========="
}

Move-ReportFilesToEORFolders

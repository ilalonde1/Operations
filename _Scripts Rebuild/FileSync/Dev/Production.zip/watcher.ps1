﻿$ErrorActionPreference = "SilentlyContinue"

# Define the root directory to watch
$watchPath = "E:\NetworkShares\Projects\Projects"

# Define the subdirectory patterns to match
$ssiPattern = "04 Construction Admin\02 SSI (Structural Site Instructions)"
$rfiPattern = "04 Construction Admin\03 RFI (Request for Info)\Sent to Inspectors"
$photosPattern = "04 Construction Admin\07 Photos"
$stickfilePattern = "05 Stickfile"

# Define the scripts to execute
$ssiScript = "C:\Ian\FileSync\Production\SINGLE_SYNC_SSI.ps1"
$rfiScript = "C:\Ian\FileSync\Production\SINGLE_SYNC_RFI.ps1"
$photosScript = "C:\Ian\FileSync\Production\SINGLE_SYNC_Photos.ps1"
$stickfileScript = "C:\Ian\FileSync\Production\SINGLE_SYNC_Stickfile.ps1"

# Logging file
$logPath = "C:\Ian\FileSync\Production\Logs\Watcher_Log.txt"

# Create a FileSystemWatcher
$watcher = New-Object System.IO.FileSystemWatcher
$watcher.Path = $watchPath
$watcher.IncludeSubdirectories = $true
$watcher.Filter = "*.*"
$watcher.InternalBufferSize = 65536  # Increase buffer size for better performance

# Hashtable to store recent events (debounce mechanism)
$recentEvents = @{}

# Debugging: Ensure the watcher is set up properly
Write-Host "Watcher setup complete. Monitoring: $watchPath"
Add-Content -Path $logPath -Value "Watcher started for: $watchPath" -Encoding utf8

# Log the patterns ONCE here
Add-Content -Path $logPath -Value "DEBUG: Expected SSI pattern - $ssiPattern" -Encoding utf8
Add-Content -Path $logPath -Value "DEBUG: Expected RFI pattern - $rfiPattern" -Encoding utf8
Add-Content -Path $logPath -Value "DEBUG: Expected Stickfile pattern - $stickfilePattern" -Encoding utf8
Add-Content -Path $logPath -Value "DEBUG: Expected Photos pattern - $photosPattern" -Encoding utf8

Write-Host "DEBUG: Expected SSI pattern - $ssiPattern"
Write-Host "DEBUG: Expected RFI pattern - $rfiPattern"
Write-Host "DEBUG: Expected Stickfile pattern - $stickfilePattern"
Write-Host "DEBUG: Expected Photos pattern - $photosPattern"


# Function to execute the correct script
function Execute-SyncScript {
    param ($directory, $scriptToRun)

    $key = "$directory|$scriptToRun"
    $currentTime = Get-Date

    # Prevent duplicate execution within 3 seconds
    if ($recentEvents[$key] -and ($currentTime - $recentEvents[$key]).TotalSeconds -lt 3) {
        Write-Host "Skipping duplicate execution for: $scriptToRun in $directory"
        return
    }

    # Store execution time
    $recentEvents[$key] = $currentTime

    Write-Host "Matched! Executing: $scriptToRun"
    Add-Content -Path $logPath -Value "Matched creation! Executing: $scriptToRun -GivenPath $directory" -Encoding utf8
    & $scriptToRun -GivenPath $directory
}

# Function to check if the control file exists in the project folder root
function ShouldIgnoreFolder {
    param ($directory)

    # Start at the detected directory and traverse upwards
    $currentDir = Get-Item $directory

    while ($currentDir -and $currentDir.FullName -ne $watchPath) {
        $controlFile = "$($currentDir.FullName)\NOT SYNCED TO ACTIVE PROJECTS.txt"
        
        # Check if the control file exists in any parent folder
        if (Test-Path $controlFile) {
            Write-Host "Skipping $directory - Control file exists in: $controlFile"
            Add-Content -Path $logPath -Value "Skipping $directory - Control file exists in: $controlFile" -Encoding utf8
            return $true
        }

        # Move up one directory level
        $currentDir = $currentDir.Parent
    }

    return $false
}

# Define event action for file creations
$createAction = {
    $path = $Event.SourceEventArgs.FullPath
    $directory = Split-Path -Path $path -Parent

    Write-Host "File created in: $directory"

    # Check if the project folder should be ignored
    if (ShouldIgnoreFolder -directory $directory) {
        return
    }

    $scriptToRun = $null

    # Ensure we are in the exact required folder (not subfolders)
    if ($directory -like "*\Projects\*\*\$stickfilePattern") {
    $scriptToRun = $stickfileScript
} elseif ($directory -like "*\Projects\*\*\$ssiPattern") {
    $scriptToRun = $ssiScript
} elseif ($directory -like "*\Projects\*\*\$rfiPattern") {
    $scriptToRun = $rfiScript
} elseif ($directory -like "*\Projects\*\*\$photosPattern") {
    $scriptToRun = $photosScript
}
 else {
    Write-Host "Ignoring: $directory (Not a target folder)"
    Add-Content -Path $logPath -Value "Ignoring: $directory (Not a target folder)" -Encoding utf8
    return
}


    # Execute sync script with duplicate prevention
    Execute-SyncScript -directory $directory -scriptToRun $scriptToRun
}

# Define event action for file deletions
$deleteAction = {
    $path = $Event.SourceEventArgs.FullPath
    $directory = Split-Path -Path $path -Parent

    Write-Host "File deleted in: $directory"

    # Check if the project folder should be ignored
    if (ShouldIgnoreFolder -directory $directory) {
        return
    }

    $scriptToRun = $null

    # Ensure we are in the exact required folder (not subfolders)
   if ($directory -like "*\Projects\*\*\$stickfilePattern") {
    $scriptToRun = $stickfileScript
} elseif ($directory -like "*\Projects\*\*\$ssiPattern") {
    $scriptToRun = $ssiScript
} elseif ($directory -like "*\Projects\*\*\$rfiPattern") {
    $scriptToRun = $rfiScript
} elseif ($directory -like "*\Projects\*\*\$photosPattern") {
    $scriptToRun = $photosScript
}
 else {
    Write-Host "Ignoring: $directory (Not a target folder)"
    Add-Content -Path $logPath -Value "Ignoring: $directory (Not a target folder)" -Encoding utf8
    return
}


    # Execute sync script with duplicate prevention
    Execute-SyncScript -directory $directory -scriptToRun $scriptToRun
}

# Define event action for file changes (modifications/overwrites)
$changeAction = {
    $path = $Event.SourceEventArgs.FullPath
    $directory = Split-Path -Path $path -Parent

    Write-Host "File changed in: $directory"

    # Check if the project folder should be ignored
    if (ShouldIgnoreFolder -directory $directory) {
        return
    }

    $scriptToRun = $null

    # Match folders
    if ($directory -like "*\Projects\*\*\$stickfilePattern") {
    $scriptToRun = $stickfileScript
} elseif ($directory -like "*\Projects\*\*\$ssiPattern") {
    $scriptToRun = $ssiScript
} elseif ($directory -like "*\Projects\*\*\$rfiPattern") {
    $scriptToRun = $rfiScript
} elseif ($directory -like "*\Projects\*\*\$photosPattern") {
    $scriptToRun = $photosScript
}
else {
        Write-Host "Ignoring: $directory (Not a target folder)"
        Add-Content -Path $logPath -Value "Ignoring: $directory (Not a target folder)" -Encoding utf8
        return
    }

    Execute-SyncScript -directory $directory -scriptToRun $scriptToRun
}


# Register events
Register-ObjectEvent $watcher "Created" -Action $createAction
Register-ObjectEvent $watcher "Deleted" -Action $deleteAction
Register-ObjectEvent $watcher "Changed" -Action $changeAction

# Enable the watcher
$watcher.EnableRaisingEvents = $true
Write-Host "Watching for changes in $watchPath..."
Add-Content -Path $logPath -Value "Service started and monitoring $watchPath" -Encoding utf8

# Keep script running
while ($true) {
    Start-Sleep -Seconds 10
}

Write-Host "Watching for changes in $watchPath..."
